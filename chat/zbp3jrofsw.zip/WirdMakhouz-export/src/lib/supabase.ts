import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Variables Supabase manquantes : VITE_SUPABASE_URL ou VITE_SUPABASE_ANON_KEY'
  );
}

export const supabase = createClient(
  supabaseUrl,
  supabaseAnonKey
);

console.log(
  'SUPABASE URL:',
  import.meta.env.VITE_SUPABASE_URL
);
console.log(
  'SUPABASE ANON KEY:',
  import.meta.env.VITE_SUPABASE_ANON_KEY
);